/* Amplify Params - DO NOT EDIT
	AUTH_AWSAMPLIFYVUEMASTERF2E00598_USERPOOLID
	ENV
	REGION
Amplify Params - DO NOT EDIT */

exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
